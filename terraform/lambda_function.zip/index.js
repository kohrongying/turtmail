exports.handler = async (event) => {
  if ('Records' in event) {
      event.Records.map(record => {
          console.log(`--------------------NOTIFICATION----------------------
MessageId: ${record.Sns.MessageId}
Timestamp: ${record.Sns.Timestamp}
Message: ${record.Sns.Message}`);
      });
     
  } else {
      console.log('No Records found')
  }
  return true;
};
